import csv
from django.shortcuts import render, redirect
from django.contrib import messages
from django.http import HttpResponse
from customers.models import Customer
from accounts.models import Account
from cards.models import Card
from branches.models import Branch

def upload_customers_csv(request):
    if request.method == 'POST':
        csv_file = request.FILES['file']
        if not csv_file.name.endswith('.csv'):
            messages.error(request, 'File is not CSV.')
            return redirect('upload_csv')

        decoded_file = csv_file.read().decode('utf-8').splitlines()
        reader = csv.DictReader(decoded_file)

        for row in reader:
            branch, _ = Branch.objects.get_or_create(name=row['branch'])
            customer, _ = Customer.objects.get_or_create(
                name=row['name'],
                email=row['email'],
                phone=row['phone'],
                branch=branch,
            )
            account, _ = Account.objects.get_or_create(
                customer=customer,
                account_number=row['account_number'],
                defaults={'balance': row.get('balance', 0)}
            )
            if row.get('card_number'):
                Card.objects.get_or_create(
                    customer=customer,
                    card_number=row['card_number'],
                    defaults={'card_type': row.get('card_type', 'Debit')}
                )

        messages.success(request, 'CSV uploaded successfully.')
        return redirect('upload_csv')

    return render(request, 'reports/upload_csv.html')


from customers.models import Customer



from django.shortcuts import render
from customers.models import Customer

from django.shortcuts import render
from customers.models import Customer

def customer_report(request):
    customers = Customer.objects.select_related('branch').prefetch_related(
        'accounts__card'  # Related name from OneToOneField in Card model
    )
    return render(request, 'reports/customer_report.html', {'customers': customers})


import csv
from django.http import HttpResponse
from customers.models import Customer
from accounts.models import Account
from cards.models import Card

def download_customer_report_csv(request):
    response = HttpResponse(content_type='text/csv')
    response['Content-Disposition'] = 'attachment; filename="customer_report.csv"'

    writer = csv.writer(response)
    writer.writerow(['Name', 'Branch', 'Account Number', 'Balance', 'Card Number', 'Card Type'])

    customers = Customer.objects.select_related('branch').prefetch_related('accounts__card')

    for customer in customers:
        for account in customer.accounts.all():
            card = getattr(account, 'card', None)
            writer.writerow([
                f"{customer.first_name} {customer.last_name}",
                customer.branch.name if customer.branch else 'N/A',
                account.account_number,
                account.balance,
                card.card_number if card else 'N/A',
                card.card_type.title() if card else 'N/A',
            ])

    return response
from openpyxl import Workbook
from django.http import HttpResponse
from customers.models import Customer
from accounts.models import Account
from cards.models import Card

def download_customer_report_excel(request):
    workbook = Workbook()
    worksheet = workbook.active
    worksheet.title = 'Customer Report'

    # Header row
    headers = ['Name', 'Branch', 'Account Number', 'Balance', 'Card Number', 'Card Type']
    worksheet.append(headers)

    customers = Customer.objects.select_related('branch').prefetch_related('accounts__card')

    for customer in customers:
        for account in customer.accounts.all():
            card = getattr(account, 'card', None)
            worksheet.append([
                f"{customer.first_name} {customer.last_name}",
                customer.branch.name if customer.branch else 'N/A',
                account.account_number,
                float(account.balance),
                card.card_number if card else 'N/A',
                card.card_type.title() if card else 'N/A',
            ])

    # Response
    response = HttpResponse(content_type='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')
    response['Content-Disposition'] = 'attachment; filename=customer_report.xlsx'
    workbook.save(response)
    return response
