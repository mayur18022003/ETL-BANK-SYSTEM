from django.shortcuts import render, redirect
from .forms import DepositForm, WithdrawForm, TransferForm
from .models import Transaction
from accounts.models import Account
from django.contrib import messages

def deposit_view(request):
    if request.method == 'POST':
        form = DepositForm(request.POST)
        if form.is_valid():
            to_account = form.cleaned_data['to_account']
            amount = form.cleaned_data['amount']
            to_account.balance += amount
            to_account.save()
            Transaction.objects.create(transaction_type='deposit', to_account=to_account, amount=amount)
            messages.success(request, 'Deposit successful.')
            return redirect('deposit')  # Redirect to deposit page
    else:
        form = DepositForm()
    return render(request, 'transactions/deposit.html', {'form': form})

def withdraw_view(request):
    if request.method == 'POST':
        form = WithdrawForm(request.POST)
        if form.is_valid():
            from_account = form.cleaned_data['from_account']
            amount = form.cleaned_data['amount']
            if from_account.balance >= amount:
                from_account.balance -= amount
                from_account.save()
                Transaction.objects.create(transaction_type='withdraw', from_account=from_account, amount=amount)
                messages.success(request, 'Withdrawal successful.')
                return redirect('withdraw')  # Redirect to withdraw page
            else:
                messages.error(request, 'Insufficient balance.')
    else:
        form = WithdrawForm()
    return render(request, 'transactions/withdraw.html', {'form': form})

def transfer_view(request):
    if request.method == 'POST':
        form = TransferForm(request.POST, Account=Account)  # Pass Account to TransferForm
        if form.is_valid():
            from_account = form.cleaned_data['from_account']
            to_account = form.cleaned_data['to_account']
            amount = form.cleaned_data['amount']
            if from_account != to_account and from_account.balance >= amount:
                from_account.balance -= amount
                to_account.balance += amount
                from_account.save()
                to_account.save()
                Transaction.objects.create(
                    transaction_type='transfer',
                    from_account=from_account,
                    to_account=to_account,
                    amount=amount
                )
                messages.success(request, 'Transfer successful.')
                return redirect('transfer')  # Redirect to transfer page
            else:
                messages.error(request, 'Invalid transfer.')
    else:
        form = TransferForm(Account=Account)  # Pass Account to TransferForm
    return render(request, 'transactions/transfer.html', {'form': form})

def transaction_list(request):
    transactions = Transaction.objects.all()
    return render(request, 'transactions/transaction_list.html', {'transactions': transactions})
