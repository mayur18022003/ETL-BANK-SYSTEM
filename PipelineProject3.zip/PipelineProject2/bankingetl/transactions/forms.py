

from django import forms
from .models import Transaction

class DepositForm(forms.ModelForm):
    class Meta:
        model = Transaction
        fields = ['to_account', 'amount']  # Assuming 'to_account' is related to Account
        widgets = {
            'to_account': forms.Select(attrs={'class': 'form-control'}),
            'amount': forms.NumberInput(attrs={'class': 'form-control'}),
        }


class WithdrawForm(forms.ModelForm):
    class Meta:
        model = Transaction
        fields = ['from_account', 'amount']  # Assuming 'from_account' is related to Account
        widgets = {
            'from_account': forms.Select(attrs={'class': 'form-control'}),
            'amount': forms.NumberInput(attrs={'class': 'form-control'}),
        }


from django import forms
from accounts.models import Account  # Ensure Account model is imported

class TransferForm(forms.Form):
    from_account = forms.ModelChoiceField(queryset=None, widget=forms.Select(attrs={'class': 'form-control'}))
    to_account = forms.ModelChoiceField(queryset=None, widget=forms.Select(attrs={'class': 'form-control'}))
    amount = forms.DecimalField(max_digits=10, decimal_places=2, widget=forms.NumberInput(attrs={'class': 'form-control'}))

    def __init__(self, *args, **kwargs):
        Account = kwargs.pop('Account', None)  # Correctly pop Account from kwargs
        super().__init__(*args, **kwargs)
        if Account:
            self.fields['from_account'].queryset = Account.objects.all()
            self.fields['to_account'].queryset = Account.objects.all()
