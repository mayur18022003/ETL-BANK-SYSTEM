from django import forms
from .models import Account

class AccountForm(forms.ModelForm):
    class Meta:
        model = Account
        fields = ['account_number', 'customer', 'account_type', 'balance']
        widgets = {
            'account_number': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Account Number'}),
            'customer': forms.Select(attrs={'class': 'form-control'}),
            'account_type': forms.Select(choices=Account.ACCOUNT_TYPES, attrs={'class': 'form-control'}),
            'balance': forms.NumberInput(attrs={'class': 'form-control', 'placeholder': 'Balance'}),
        }
