# cards/views.py

from django.shortcuts import render, redirect, get_object_or_404
from .models import Card
from .forms import CardForm
from django.contrib import messages
from accounts.models import Account   

def card_list(request):
    cards = Card.objects.all()
    return render(request, 'cards/card_list.html', {'cards': cards})

def issue_card(request):
    if request.method == 'POST':
        form = CardForm(request.POST)
        if form.is_valid():
            card = form.save(commit=False)
            account = Account.objects.filter(customer=card.customer, card__isnull=True).first()
            if not account:
                form.add_error(None, "No available account found for this customer.")
            else:
                card.account = account
                card.save()
                return redirect('card_list')
    else:
        form = CardForm()
    return render(request, 'cards/issue_card.html', {'form': form})

def block_card(request, pk):
    card = get_object_or_404(Card, pk=pk)
    card.status = 'blocked'
    card.save()
    messages.success(request, 'Card blocked successfully.')
    return redirect('card_list')

def renew_card(request, pk):
    card = get_object_or_404(Card, pk=pk)
    card.status = 'active'
    messages.success(request, 'Card renewed successfully.')
    card.save()
    return redirect('card_list')

