from django.shortcuts import render

# dashboard/views.py
from django.shortcuts import render
#from .models import Loan, Account, Transaction, Customer
from loans.models import Loan
from accounts.models import Account
from transactions.models import Transaction
from customers.models import Customer
from django.db.models import Sum, Count

def dashboard_view(request):
    # Example queries for key metrics
    total_loans = Loan.objects.count()
    total_accounts = Account.objects.count()
    total_transactions = Transaction.objects.count()
    total_customers = Customer.objects.count()

    # Get total amount of EMIs paid
    #total_emi_paid = Transaction.objects.filter(description='EMI Payment').aggregate(Sum('amount'))['amount__sum']

    context = {
        'total_loans': total_loans,
        'total_accounts': total_accounts,
        'total_transactions': total_transactions,
        'total_customers': total_customers,
        #'total_emi_paid': total_emi_paid,
    }

    return render(request, 'dashboard/dashboard.html', context)

