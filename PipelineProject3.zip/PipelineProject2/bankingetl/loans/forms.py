# loans/forms.py
from django import forms
from .models import Loan

class LoanForm(forms.ModelForm):
    class Meta:
        model = Loan
        fields = ['customer', 'loan_type', 'amount', 'tenure_months', 'emi_amount', 'linked_account']
        widgets = {
            'customer': forms.Select(attrs={'class': 'form-control'}),
            'loan_type': forms.Select(attrs={'class': 'form-control'}),
            'amount': forms.NumberInput(attrs={'class': 'form-control'}),
            'tenure_months': forms.NumberInput(attrs={'class': 'form-control'}),
            'emi_amount': forms.NumberInput(attrs={'class': 'form-control'}),
            'linked_account': forms.Select(attrs={'class': 'form-control'}),
        }
