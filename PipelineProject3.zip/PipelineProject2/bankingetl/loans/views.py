

# loans/views.py
from django.shortcuts import render, redirect
from .forms import LoanForm
from .models import Loan

def apply_loan(request):
    if request.method == 'POST':
        form = LoanForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('loan_list')
    else:
        form = LoanForm()
    return render(request, 'loans/apply_loan.html', {'form': form})

#def loan_list(request):
    #loans = Loan.objects.select_related('customer', 'linked_account')
    #return render(request, 'loans/loan_list.html', {'loans': loans})
def loan_list(request):
    loans = Loan.objects.select_related('customer').all()
    return render(request, 'loans/loan_list.html', {'loans': loans})
